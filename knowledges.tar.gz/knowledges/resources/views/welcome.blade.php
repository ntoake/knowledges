@extends('layouts.front')

@section('content')


フロントなかみ111

@endsection