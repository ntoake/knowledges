<ul class="sharepostList">     
    <?php $__currentLoopData = $shareposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sharepost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="sharepostList__item">
            <a href="<?php echo e(route('shareposts.show', ['sharepost' => $sharepost->id])); ?>">
                <time class="sharepostList__date" datetime="<?php echo e($sharepost->created_at); ?>">
                <?php echo e($sharepost->created_at->format('Y年n月d日')); ?></time>                      
                <span class="sharepostList__author">著者：<?php echo e($sharepost->user->name); ?></span>
                <p class="sharepostList__ttl"><?php echo e($sharepost->title); ?></p>                            
                <ul class="sharepostTag">                           
                    <?php $__currentLoopData = $sharepost->postHaveTag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posttag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="sharepostTag__item"><?php echo e($posttag->tag); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul> 
                

                  
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
</ul> <?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/commons/sharepost.blade.php ENDPATH**/ ?>