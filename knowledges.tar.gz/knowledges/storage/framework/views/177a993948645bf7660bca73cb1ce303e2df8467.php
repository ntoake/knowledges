<?php $__env->startSection('content'); ?>

    
    <?php if(Auth::check()): ?>

    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">

            <?php if(count($shareposts) > 0): ?>
            
                <?php echo $__env->make('layouts.countpost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
                <?php echo $__env->make('admin.commons.sharepost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                
                <?php echo e($shareposts->appends(request()->query())->links()); ?>          
                
            <?php else: ?> 
                <p>対象記事がありません。</p>
            <?php endif; ?>

        </div>
    </div>  

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/search/index.blade.php ENDPATH**/ ?>