<?php $__env->startSection('content'); ?>




    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">
            
            <h1 class="">アカウント内容</h1>
            
            <div class="">
                <ul class="">
                    <li class="">
                        <span>名前:</span>
                        <?php echo e($user->name); ?>

                    </li>
                    <li class="">
                        <span>メールアドレス:</span>
                        <?php echo e($user->email); ?>

                    </li>  
                    
                </ul>
            </div>
          
            <div class="">
                <ul class="">
                    
                    <li class="">

                        
                        <?php echo e(Form::model($user, ['route' => ['users.destroy', $user->id], 'method' => 'delete'])); ?>

                        
                            <div class="btnEle btnEle--single">
                                <?php echo e(Form::submit('アカウント削除', ['class' => ''])); ?>

                            </div>           
                            
                        <?php echo e(Form::close()); ?>

                    </li>  
                </ul>
            </div>




        </div>
    </div>  
    







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/users/show.blade.php ENDPATH**/ ?>