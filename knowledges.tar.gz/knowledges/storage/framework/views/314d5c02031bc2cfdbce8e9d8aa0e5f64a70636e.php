<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Laravel</title>

        <?php echo $__env->yieldContent('css'); ?>
       
        <link rel="stylesheet" type="text/css" href="/assets/css/index.css">




    </head>
    <body>

       <div class="l-wrapper"> 
            <header class="l-header headerWrap">
                <h1 class="headerTtl">ナレッジ共有サイト</h1>
                
                <?php if(Auth::check()): ?>
                
     
     
                
                    <div>
                        こんにちは、<?php echo e(Auth::user()->name); ?>さん
                    </div>
                    <ul class="headerNav">
                        <li class="headerNav__item">
                            <a href="<?php echo e(route('users.show', ['user' => Auth::id()])); ?>">
                                マイアカウント
                            </a>
                        </li>
                        <li class="headerNav__item">
                            <a href="<?php echo e(route('logout.get')); ?>">
                                ログアウト
                            </a>
                        </li>
                    </ul>
                    
                <?php endif; ?>
                
            </header>
            <main class="l-main">
                
                <?php echo $__env->yieldContent('content'); ?>

                
            </main>
            <foote class="l-footer">
                &copy; 2021 XXXX
                
            </footer>   
       </div>
       <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>
<?php /**PATH /home/ubuntu/environment/knowledges/resources/views/layouts/admin.blade.php ENDPATH**/ ?>