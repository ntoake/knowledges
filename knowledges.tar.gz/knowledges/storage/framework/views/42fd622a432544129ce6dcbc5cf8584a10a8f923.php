<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(Auth::check()): ?>
    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">



            <?php echo $__env->make('admin.commons.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
   
      
                <?php echo e(Form::model($tag, ['route' => ['tags.update', $tag->id], 'method' => 'put'])); ?>

                
                <div>
                    <div class="">
                        <?php echo e(Form::label('tag', 'タグ名')); ?>

                        <?php echo e(Form::text('tag', old('tag'), ['class' => ''])); ?>

                    </div>
      
                </div>   

                <div class="btnEle btnEle--single">
                    <?php echo e(Form::submit('タグを更新する', ['class' => ''])); ?>

                </div>
                
                <?php echo e(Form::close()); ?>

        

            

            <div class="btnEle btnEle--single">
                <a href="<?php echo e(route('shareposts.index')); ?>">
                    記事一覧に戻る
                </a>
            </div>
        </div>
    </div>  
    
    <?php endif; ?>
    
    
    


    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/tags/edit.blade.php ENDPATH**/ ?>