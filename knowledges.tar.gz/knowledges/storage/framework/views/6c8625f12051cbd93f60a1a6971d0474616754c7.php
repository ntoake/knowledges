    <div class="searchSection">

        <input id="searchSection__input" class="searchSection__input" type="checkbox">
        <label class="searchSection__label" for="searchSection__input">検索条件を指定する</label>       
        
        <div class="searchSection__detail">
            <?php echo e(Form::open(['route' => $routeName, 'method' => 'get'])); ?>

                <?php echo e(Form::label('search_query', '検索テキスト')); ?>

                <?php echo e(Form::text('search_query', old('search_query'), ['class' => ''])); ?>

                <ul class="tagCheckList">
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="tagCheckList__item">
                        <?php echo e(Form::checkbox('tagname[]', $tag->id, false, ['id'=>$tag->tag])); ?>

                        <?php echo e(Form::label($tag->tag, $tag->tag)); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="btnEle">
                    <?php echo Form::submit('記事を検索する', ['class' => '']); ?>

                </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/layouts/search_section.blade.php ENDPATH**/ ?>