            <div class="currentPages">  
                <p>現在のページ数: <?php echo e($tags->currentPage()); ?></p>
                <p>総件数: <?php echo e($tags -> total()); ?>件</p>
                
                <?php if($tags->perPage() > $tags->total()): ?>
                    
                    <p>1〜<?php echo e($tags -> total()); ?>件目を表示しています。</p>
                <?php else: ?>
                    <?php if($tags->currentPage() == $tags->lastPage()): ?>
                        
                        <p><?php echo e(($tags->lastPage() - 1) * $tags->perPage() + 1); ?>〜<?php echo e($tags -> total()); ?>

                            件目を表示しています。</p>
                    <?php else: ?>
                        <p><?php echo e(($tags->currentPage() - 1) * $tags->perPage() + 1); ?>〜<?php echo e($tags->currentPage() * $tags->perPage()); ?>

                            件目を表示しています。</p>        
                    <?php endif; ?>              
                <?php endif; ?>
            </div>  <?php /**PATH /home/ubuntu/environment/knowledges/resources/views/layouts/counttag.blade.php ENDPATH**/ ?>