<?php $__env->startSection('css'); ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<script src="/js/summernote.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(Auth::check()): ?>
    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">



            <?php echo $__env->make('admin.commons.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            

                <?php echo e(Form::model($sharepost, ['route' => ['shareposts.update', $sharepost->id], 'method' => 'put'])); ?>

                
                <div>
                    <div class="">
                        <?php echo e(Form::label('title', 'タイトル')); ?>

                        <?php echo e(Form::text('title', old('title'), ['class' => ''])); ?>

                    </div>
                    <div class="">
                        <?php echo e(Form::label('content', 'コンテンツ')); ?>

                        <?php echo e(Form::textarea('content', old('content'), ['class' => 'js-summernote'])); ?>       
                    </div> 
                    
                    <ul class="tagCheckList">
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="tagCheckList__item">

                            
                            <?php $__currentLoopData = $sharepost->postHaveTag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posttag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($tag->id == $posttag->id): ?>
                                    <?php $tagCheckBoxFlag = true; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php echo e(Form::checkbox('tagname[]', $tag->id, $tagCheckBoxFlag, ['id'=>$tag->tag])); ?>

                            <?php echo e(Form::label($tag->tag, $tag->tag)); ?>

                            </li>
                            
                            
                            <?php $tagCheckBoxFlag = false; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>   
                    
                    <dl>
                        <dt>画像の削除について</dt>
                        <dd>
                            <ul>
                                <li>削除する際は、画像を選択肢、ゴミ箱ボタンを押して削除してください。<li>
                                <li>記事更新に関係なく実行されます。<li>
                            </ul>      
                        </dd>
                    </dl>
                </div>   

                <div class="btnEle btnEle--single">
                    <?php echo e(Form::submit('記事を更新する', ['class' => ''])); ?>

                </div>
                
                <?php echo e(Form::close()); ?>

        

            

            <div class="btnEle btnEle--single">
                <a href="<?php echo e(route('shareposts.index')); ?>">
                    記事一覧に戻る
                </a>
            </div>
        </div>
    </div>  
    
    <?php endif; ?>
    
    
    


    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/shareposts/edit.blade.php ENDPATH**/ ?>