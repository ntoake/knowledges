<?php $__env->startSection('content'); ?>



<div class="oneColumnContent">
    <?php echo $__env->make('admin.commons.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo e(Form::open(['route' => 'signup.post'])); ?>

        <div class="">
            <?php echo e(Form::label('name', '名前')); ?>

            <?php echo e(Form::text('name', old('name'), ['class' => ''])); ?>

        </div>

        <div class="">
            <?php echo e(Form::label('email', 'メールアドレス')); ?>

            <?php echo e(Form::email('email', old('email'), ['class' => ''])); ?>

        </div>

        <div class="">
            <?php echo e(Form::label('password', 'パスワード')); ?>

            <?php echo e(Form::password('password', ['class' => ''])); ?>

        </div>

        <div class="">
            <?php echo e(Form::label('password_confirmation', 'パスワード確認')); ?>

            <?php echo e(Form::password('password_confirmation', ['class' => ''])); ?>

        </div>

        <div class="btnEle btnEle--single">
            <?php echo e(Form::submit('新規登録する', ['class' => ''])); ?>

        </div>     
        
    <?php echo e(Form::close()); ?>

    
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/auth/register.blade.php ENDPATH**/ ?>