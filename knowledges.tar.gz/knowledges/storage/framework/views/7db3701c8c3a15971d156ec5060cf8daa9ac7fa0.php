            <div class="currentPages">   
                <p>現在のページ数: <?php echo e($shareposts->currentPage()); ?></p>
                <p>総件数: <?php echo e($shareposts -> total()); ?>件</p>
                
                <?php if($shareposts->perPage() > $shareposts->total()): ?>
                    
                    <p>1〜<?php echo e($shareposts -> total()); ?>件目を表示しています。</p>
                <?php else: ?>
                    <?php if($shareposts->currentPage() == $shareposts->lastPage()): ?>
                        
                        <p><?php echo e(($shareposts->lastPage() - 1) * $shareposts->perPage() + 1); ?>〜<?php echo e($shareposts -> total()); ?>

                            件目を表示しています。</p>
                    <?php else: ?>
                        <p><?php echo e(($shareposts->currentPage() - 1) * $shareposts->perPage() + 1); ?>〜<?php echo e($shareposts->currentPage() * $shareposts->perPage()); ?>

                            件目を表示しています。</p>        
                    <?php endif; ?>              
                <?php endif; ?>
            </div> <?php /**PATH /home/ubuntu/environment/knowledges/resources/views/layouts/countpost.blade.php ENDPATH**/ ?>