        <aside class="adminContents__side">
            <ul class="adminSideNav">
                <li class="adminSideNav__item">
                    <a href="<?php echo e(route('admin')); ?>">
                        管理画面TOP     
                    </a>
                </li>                 
                <li class="adminSideNav__item">
                    記事
                    <ul class="adminSideNavLower">
                        <li class="">
                            -
                            <a href="<?php echo e(route('shareposts.create')); ?>">
                                新規記事登録
                            </a>
                        </li>      
                        </li class="">
                            -
                            <a href="<?php echo e(route('tags.index')); ?>">
                                記事タグ
                            </a>
                        </li>
                    </ul>   
                </li>
                <li class="adminSideNav__item">  
                    <a href="<?php echo e(route('users.show', ['user' => Auth::id()])); ?>">
                        マイアカウント
                    </a>
                </li>
                <li class="adminSideNav__item">
                    <a href="/admin/contact/">
                        問い合わせ    
                    </a>
                </li>                
            </ul>   
        </aside><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/commons/sidebar.blade.php ENDPATH**/ ?>