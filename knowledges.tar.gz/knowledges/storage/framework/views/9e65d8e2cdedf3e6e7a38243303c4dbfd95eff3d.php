<?php $__env->startSection('content'); ?>




    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">
            
            <h1 class="">アカウント内容</h1>
            
            <?php echo $__env->make('admin.commons.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="">
                <ul class="">
                    <?php echo e(Form::model($user, ['route' => ['users.update', $user->id], 'method' => 'put'])); ?>

                        <div class="">
                            <?php echo e(Form::label('name', '名前')); ?>

                            <?php echo e(Form::text('name', old('name'), ['class' => ''])); ?>

                        </div>
                
                        <div class="">
                            <?php echo e(Form::label('email', 'メールアドレス')); ?>

                            <?php echo e(Form::email('email', old('email'), ['class' => ''])); ?>

                        </div>
                
                        <div class="">
                            <?php echo e(Form::label('password', 'パスワード')); ?>

                            <?php echo e(Form::password('password', ['class' => ''])); ?>

                        </div>
                
                        <div class="">
                            <?php echo e(Form::label('password_confirmation', 'パスワード確認')); ?>

                            <?php echo e(Form::password('password_confirmation', ['class' => ''])); ?>

                        </div>
                
                        <?php echo e(Form::submit('更新する', ['class' => ''])); ?>

                    <?php echo e(Form::close()); ?>

                </ul>
                
    
            </div>
          

            
        </div>
    </div>  
    







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>