<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <?php if(Auth::check()): ?>
    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">


            <div class="sharepostUnit">
                
                <div class="sharepostUnit__status">

                    <time class="sharepostUnit__date" datetime="<?php echo e($sharepost->created_at); ?>">
                    <?php echo e($sharepost->created_at->format('Y年n月d日')); ?>

                    </time>                      
                    <span class="sharepostUnit__author">
                        著者：<?php echo e($sharepost->user->name); ?>

                    </span>    
                </div>  
 
                <ul class="sharepostUnitTag">                       
                    <?php $__currentLoopData = $sharepost->postHaveTag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posttag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="sharepostUnitTag__item"><?php echo e($posttag->tag); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul> 
 
                <h2 class="sharepostUnit__ttl">
                    <?php echo e($sharepost->title); ?>

                </h2>
                <div class="sharepostUnit__content">
                    <?php echo $sharepost->content; ?>  
                </div>

            </div>
            

            <div class="btnEle">
                <a href="<?php echo e(route('shareposts.edit', ['sharepost' => $sharepost->id])); ?>">
                    記事を編集する
                </a>

                
                <?php echo Form::model($sharepost, ['route' => ['shareposts.destroy', $sharepost->id], 'method' => 'delete']); ?>

                    <?php echo Form::submit('記事を削除する', ['class' => '']); ?>

                <?php echo Form::close(); ?>

            </div>
            
            
            <div class="btnEle btnEle--single">
                <a href="<?php echo e(route('shareposts.index')); ?>">
                    記事一覧に戻る
                </a>
            </div>
        </div>
    </div>  
    
    <?php endif; ?>
    
    
    


    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/shareposts/show.blade.php ENDPATH**/ ?>