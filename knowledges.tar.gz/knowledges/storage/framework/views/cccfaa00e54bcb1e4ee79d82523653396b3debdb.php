<?php $__env->startSection('content'); ?>


<div class="oneColumnContent">
    <?php echo $__env->make('admin.commons.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo e(Form::open(['route' => 'login.post'])); ?>

        <div class="">
            <?php echo e(Form::label('email', 'メールアドレス')); ?>

            <?php echo e(Form::email('email', old('email'), ['class' => ''])); ?>

        </div>

        <div class="">
            <?php echo e(Form::label('password', 'パスワード')); ?>

            <?php echo e(Form::password('password', ['class' => ''])); ?>

        </div>

        <div class="btnEle btnEle--single">
            <?php echo e(Form::submit('ログイン', ['class' => ''])); ?>

        </div> 
        
    <?php echo e(Form::close()); ?>

</div>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>