            <div class="searchConditions">
                <dl>
                    <dt class="searchConditions__ttl">検索条件</dt>
                    <dd>
                        <?php if($searchTxt != '' && empty($searchTags)): ?>
                            <p>検索テキスト：<?php echo e($searchTxt); ?></p>
                            
                        <?php elseif($searchTxt == null && empty($searchTags) == false): ?>
                            <div class="searchConditions__tagWrap">
                                <p class="searchConditions__tag">検索タグ：</p>
                                <ul class="searchConditionsList">
                                    <?php $__currentLoopData = $searchTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="searchConditionsList__item"> <?php echo e($searchTag); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php elseif($searchTxt != '' && empty($searchTags) == false): ?>                     
                            <p>検索テキスト：<?php echo e($searchTxt); ?></p>
                            
                            <div class="searchConditions__tagWrap">
                                <p class="searchConditions__tag">検索タグ：</p>
                                <ul class="searchConditionsList">
                                    <?php $__currentLoopData = $searchTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchTag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="searchConditionsList__item"> <?php echo e($searchTag); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php else: ?>
                            <p>検索指定はありません</p>
                        <?php endif; ?>
                    </dd>
                </dl>
            </div>
<?php /**PATH /home/ubuntu/environment/knowledges/resources/views/layouts/search_conditions.blade.php ENDPATH**/ ?>