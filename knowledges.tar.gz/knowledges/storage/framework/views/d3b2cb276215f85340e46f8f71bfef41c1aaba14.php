<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <?php if(Auth::check()): ?>
    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="adminContents__main">

            <div class="sharepostUnit">
                <h2 class="sharepostUnit__ttl">
                    <?php echo e($tag->tag); ?>

                </h2>
            </div>

            <div class="btnEle">
                <a href="<?php echo e(route('tags.edit', ['tag' => $tag->id])); ?>">
                    タグを編集する
                </a>
                <?php echo Form::model($tag, ['route' => ['tags.destroy', $tag->id], 'method' => 'delete']); ?>

                    <?php echo Form::submit('タグを削除する', ['class' => '']); ?>

                <?php echo Form::close(); ?>

            </div>

            <div class="btnEle btnEle--single">
                <a href="<?php echo e(route('tags.index')); ?>">
                    タグ一覧に戻る
                </a>
            </div>
        </div>
    </div>  
    
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/tags/show.blade.php ENDPATH**/ ?>