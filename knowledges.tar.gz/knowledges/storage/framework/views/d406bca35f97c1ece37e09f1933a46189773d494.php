<?php $__env->startSection('content'); ?>


    <?php if(Auth::check()): ?>
    <div class="adminContents">

        <?php echo $__env->make('admin.commons.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="adminContents__main">

            <?php if(count($tags) > 0): ?>
            
                <?php echo $__env->make('layouts.countpost', ['shareposts' => $tags], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <ul class="sharepostList">     
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                        <li class="sharepostList__item">
                            <a href="<?php echo e(route('tags.show', ['tag' => $tag->id])); ?>">
                                <?php echo e($tag->tag); ?>

                            </a>
                        </li>
    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                </ul>            
                
                <?php echo e($tags->links()); ?>              
                
            <?php else: ?> 
                <p>現在タグがありません。</p>
            <?php endif; ?>
            
            <div class="btnEle btnEle--single">
                <a href="<?php echo e(route('tags.create')); ?>">
                    タグを作成する
                </a>
            </div>
            
        </div>
    </div>  
    <?php endif; ?>   
    
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/admin/tags/index.blade.php ENDPATH**/ ?>