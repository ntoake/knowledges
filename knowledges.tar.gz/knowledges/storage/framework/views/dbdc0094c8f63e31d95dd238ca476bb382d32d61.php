<?php $__env->startSection('content'); ?>



<div class="oneColumnContent">
    
    <?php echo $__env->make('layouts.search_section', ['routeName' => 'front'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.search_conditions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(count($shareposts) > 0): ?>
    
        <?php echo $__env->make('layouts.countpost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
        <ul class="sharepostList">     
            <?php $__currentLoopData = $shareposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sharepost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li class="sharepostList__item">
                    <a href="<?php echo e(route('front.show', ['sharepost' => $sharepost->id])); ?>">
                        <time class="sharepostList__date" datetime="<?php echo e($sharepost->created_at); ?>">
                        <?php echo e($sharepost->created_at->format('Y年n月d日')); ?></time>                      
                        <span class="sharepostList__author">著者：<?php echo e($sharepost->user->name); ?></span>               
                        
                        <p class="sharepostList__ttl"><?php echo e($sharepost->title); ?></p>
                
                        <ul class="sharepostTag">                           
                            <?php $__currentLoopData = $sharepost->postHaveTag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posttag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="sharepostTag__item"><?php echo e($posttag->tag); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>  
                          
                    </a>
                </li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
        </ul>            
        
        <?php echo e($shareposts->appends(request()->query())->links()); ?>            
    <?php else: ?> 
        <p>現在記事がありません。</p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/knowledges/resources/views/front/index.blade.php ENDPATH**/ ?>